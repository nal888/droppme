// ftol — file transfer one-liner generator
// All client-side, no backend.

let templates = [];

const ipInput = document.getElementById('ip');
const portInput = document.getElementById('port');
const filenameInput = document.getElementById('filename');
const output = document.getElementById('output');
const toast = document.getElementById('toast');

// Load templates from JSON
async function loadTemplates() {
    try {
        const res = await fetch('templates.json');
        const data = await res.json();
        templates = data.techniques;
        render();
    } catch (err) {
        output.innerHTML = '<p style="color:#f85149;padding:1rem;">Error loading templates.json</p>';
        console.error(err);
    }
}

// Replace placeholders with current input values
function fillTemplate(cmdTemplate) {
    const ip = ipInput.value.trim() || '<ATTACKER_IP>';
    const port = portInput.value.trim() || '<PORT>';
    const filename = filenameInput.value.trim() || '<FILENAME>';

    // Auto-derived output paths
    const winOut = `C:\\temp\\${filename}`;
    const nixOut = `/tmp/${filename}`;

    return cmdTemplate
        .replaceAll('{ip}', ip)
        .replaceAll('{port}', port)
        .replaceAll('{filename}', filename)
        .replaceAll('{win_out}', winOut)
        .replaceAll('{nix_out}', nixOut);
}

// Group techniques by OS for display
function groupByOS(techs) {
    const groups = { windows: [], linux: [], any: [] };
    techs.forEach(t => {
        if (groups[t.os]) groups[t.os].push(t);
        else groups.any.push(t);
    });
    return groups;
}

// Render the technique list
function render() {
    const groups = groupByOS(templates);
    output.innerHTML = '';

    if (groups.windows.length) {
        output.appendChild(renderSection('Windows', 'windows', groups.windows));
    }
    if (groups.linux.length) {
        output.appendChild(renderSection('Linux', 'linux', groups.linux));
    }
    if (groups.any.length) {
        output.appendChild(renderSection('Cross-platform', 'cross', groups.any));
    }
}

function renderSection(title, cssClass, techs) {
    const section = document.createElement('section');
    section.className = 'os-section';

    const heading = document.createElement('h2');
    heading.className = `os-heading ${cssClass}`;
    heading.textContent = title;
    section.appendChild(heading);

    techs.forEach(t => section.appendChild(renderTechnique(t)));
    return section;
}

function renderTechnique(tech) {
    const card = document.createElement('div');
    card.className = 'technique';
    card.dataset.id = tech.id;

    // Header with label + tags
    const header = document.createElement('div');
    header.className = 'technique-header';

    const label = document.createElement('div');
    label.className = 'technique-label';
    label.textContent = tech.label;
    header.appendChild(label);

    const tags = document.createElement('div');
    tags.className = 'technique-tags';
    if (tech.shell && tech.shell !== 'any') {
        tags.appendChild(makeTag(tech.shell));
    }
    if (tech.fileless) {
        tags.appendChild(makeTag('fileless', 'fileless'));
    }
    header.appendChild(tags);

    card.appendChild(header);

    // Command box with copy button
    const filled = fillTemplate(tech.command);

    const codeWrap = document.createElement('div');
    codeWrap.className = 'command-box';
    codeWrap.textContent = filled;

    const copyBtn = document.createElement('button');
    copyBtn.className = 'copy-btn';
    copyBtn.textContent = '📋 copy';
    copyBtn.addEventListener('click', e => {
        e.stopPropagation();
        copyToClipboard(filled, copyBtn);
    });
    codeWrap.appendChild(copyBtn);

    card.appendChild(codeWrap);

    // Notes
    if (tech.notes) {
        const notes = document.createElement('div');
        notes.className = 'notes';
        notes.textContent = tech.notes;
        card.appendChild(notes);
    }

    return card;
}

function makeTag(text, extraClass = '') {
    const tag = document.createElement('span');
    tag.className = 'tag' + (extraClass ? ' ' + extraClass : '');
    tag.textContent = text;
    return tag;
}

// Copy to clipboard with toast + button feedback
function copyToClipboard(text, btn) {
    navigator.clipboard.writeText(text).then(() => {
        showToast('Copied!');
        if (btn) {
            const original = btn.textContent;
            btn.textContent = '✓ copied';
            btn.classList.add('copied');
            setTimeout(() => {
                btn.textContent = original;
                btn.classList.remove('copied');
            }, 1500);
        }
    }).catch(err => {
        console.error('Copy failed:', err);
        showToast('Copy failed — try manually');
    });
}

function showToast(msg) {
    toast.textContent = msg;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 1500);
}

// Re-render commands whenever inputs change (debounced lightly)
let renderTimer;
function debouncedRender() {
    clearTimeout(renderTimer);
    renderTimer = setTimeout(render, 100);
}

[ipInput, portInput, filenameInput].forEach(el => {
    el.addEventListener('input', debouncedRender);
});

// URL params support — bookmark with ?ip=X&port=Y&filename=Z
function loadFromQuery() {
    const params = new URLSearchParams(window.location.search);
    if (params.has('ip')) ipInput.value = params.get('ip');
    if (params.has('port')) portInput.value = params.get('port');
    if (params.has('filename')) filenameInput.value = params.get('filename');
}

loadFromQuery();
loadTemplates();
