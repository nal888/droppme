# ftol

> File transfer one-liner generator. Static web app, all client-side.

Generates ready-to-paste file transfer commands for Windows and Linux targets across multiple methods. Inspired by [revshells.com](https://revshells.com), but focused exclusively on file transfer — not reverse shells.

## What it does

Given an attacker IP, port, and filename, ftol generates one-liner commands to transfer that file to a target — in many languages and tools. Pick whichever works in the target's environment.

Useful when:
- The first method fails (PowerShell blocked, `curl` not installed, etc.)
- You need an alternative quickly without searching blog posts
- You're learning the variety of file-transfer techniques

## Usage

1. Open the site
2. Enter your attacker IP, port, and the filename you're transferring
3. Click the copy button on whichever technique fits
4. Paste into the target shell

Bookmark with parameters in the URL:
```
https://yourname.github.io/ftol/?ip=10.10.14.46&port=8000&filename=payload.exe
```

## Adding new techniques

Edit `templates.json`. Each entry:

```json
{
  "id": "unique_id",
  "label": "Display name",
  "os": "windows | linux | any",
  "shell": "powershell | cmd | bash | any",
  "fileless": true,
  "command": "command with {ip} {port} {filename} {win_out} {nix_out} placeholders",
  "notes": "Caveats, when to use, what to watch for."
}
```

Available placeholders:
- `{ip}` — attacker IP
- `{port}` — attacker port
- `{filename}` — filename being transferred
- `{win_out}` — auto-derived: `C:\temp\<filename>`
- `{nix_out}` — auto-derived: `/tmp/<filename>`

## Local development

Just open `index.html` in a browser. Or serve with any static server:

```bash
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Deploying to GitHub Pages

1. Push this folder to a GitHub repo
2. Settings → Pages → Source → "Deploy from a branch" → main / root
3. Wait a minute, your site lives at `https://USERNAME.github.io/REPONAME/`

## Tech

- Vanilla HTML, CSS, JavaScript — no framework, no build step
- Templates as JSON for easy editing
- All processing client-side, no data leaves the browser

## License

MIT (or whatever you want — your repo)
